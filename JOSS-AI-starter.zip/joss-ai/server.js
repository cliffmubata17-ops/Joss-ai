import express from 'express';
import OpenAI from 'openai';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';
dotenv.config();

const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
app.use(express.json({ limit: '12mb' }));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/status', (_req, res) => res.json({
  ready: Boolean(process.env.OPENAI_API_KEY),
  model: process.env.OPENAI_MODEL || 'gpt-5.5'
}));

app.post('/api/chat', async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) return res.status(503).json({ error: 'JOSS is not connected yet. Add your OpenAI API key to the server .env file.' });
    const { messages = [], webSearch = false } = req.body || {};
    if (!Array.isArray(messages) || !messages.length) return res.status(400).json({ error: 'Please enter a message.' });
    const safeMessages = messages.slice(-20).map(m => {
      const role = m.role === 'assistant' ? 'assistant' : 'user';
      if (typeof m.content === 'string') return { role, content: m.content.slice(0, 12000) };
      if (role === 'assistant') return { role, content: String(m.text || '').slice(0, 12000) };
      const content = [];
      if (m.text) content.push({ type: 'input_text', text: String(m.text).slice(0, 12000) });
      if (m.image && /^data:image\/(png|jpeg|jpg|webp|gif);base64,/.test(m.image)) content.push({ type: 'input_image', image_url: m.image });
      return { role, content: content.length ? content : [{ type: 'input_text', text: ' ' }] };
    });
    const response = await new OpenAI({ apiKey: process.env.OPENAI_API_KEY }).responses.create({
      model: process.env.OPENAI_MODEL || 'gpt-5.5',
      instructions: 'You are JOSS, a capable, friendly, honest general-purpose AI assistant. Help with learning, writing, reasoning, planning, coding, and understanding images. Be clear about uncertainty and never claim to have performed actions you did not perform.',
      input: safeMessages,
      ...(webSearch ? { tools: [{ type: 'web_search' }] } : {})
    });
    res.json({ text: response.output_text || 'I could not produce a text response. Please try again.' });
  } catch (error) {
    console.error('JOSS API error:', error?.message || error);
    res.status(500).json({ error: error?.status === 401 ? 'The API key was rejected. Check the key in your server .env file.' : 'JOSS could not reach the AI service. Check your connection and server settings, then try again.' });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`JOSS AI running at http://localhost:${port}`));
