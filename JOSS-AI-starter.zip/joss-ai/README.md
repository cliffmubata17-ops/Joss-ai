# JOSS AI — Website + Android starter

JOSS is a responsive installable web app with a Node.js backend. The same `public/` interface can be wrapped as an Android app using Capacitor.

## What is included
- Chat interface, local chat history, suggested prompts
- OpenAI Responses API connection on the server
- Optional built-in web search toggle
- Image upload and image understanding
- Browser speech-to-text where supported
- Installable PWA shell
- Capacitor configuration for Android packaging

## 1. Connect the AI
1. Install Node.js 20 or newer.
2. In this folder run `npm install`.
3. Copy `.env.example` to `.env`.
4. Add your OpenAI API key to `OPENAI_API_KEY` in `.env`.
5. Keep `.env` private. Never put the key in `public/` or commit it to Git.
6. Run `npm start` and open `http://localhost:3000`.

API usage is billed separately by the API provider; a ChatGPT subscription does not include API credits. Set spending limits in your API account.

## 2. Put the website online
Deploy the Node project to a Node-compatible host that supports environment variables and HTTPS. Set `OPENAI_API_KEY`, `OPENAI_MODEL` (optional), and `PORT` in the host's environment settings. Do not deploy the API key in frontend files.

## 3. Build the Android app
After deploying the backend and website over HTTPS, configure Capacitor's `server.url` in `capacitor.config.json` to your deployed JOSS website URL (and remove `webDir` if using a remote URL), then run:

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

Use Android Studio to build a signed APK/AAB. Android Studio and the Android SDK are required; this starter ZIP does not contain a compiled APK.

## Important production work still needed
This is a functional starter, not a production launch. Before opening it to public users, add authentication, per-user server-side chat storage, rate limiting, abuse protection, upload scanning/limits, privacy policy, terms, account deletion, and payment/budget controls. Browser chat history is currently stored locally on the device. The web-search toggle invokes the Responses API web search tool.
